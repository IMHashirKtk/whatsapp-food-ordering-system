import * as menuRepository from "./menu.repository.js";
import AppError from "../../utils/AppError.js";

class MenuService {
  // =====================================
  // CATEGORY
  // =====================================

  async createCategory(data) {
    const exists = await menuRepository.findCategoryByName(data.name);

    if (exists) {
      throw new AppError("Category already exists.", 409);
    }

    return menuRepository.createCategory(data);
  }

  async getAllCategories() {
    return menuRepository.getAllCategories();
  }

  async getCategoryById(id) {
    const category = await menuRepository.getCategoryById(id);

    if (!category) {
      throw new AppError("Category not found.", 404);
    }

    return category;
  }

  async updateCategory(id, data) {
    await this.getCategoryById(id);

    return menuRepository.updateCategory(id, data);
  }

  async deleteCategory(id) {
    await this.getCategoryById(id);

    return menuRepository.deleteCategory(id);
  }

  // =====================================
  // MENU ITEMS
  // =====================================

  async createMenuItem(data) {
    await this.getCategoryById(data.categoryId);

    return menuRepository.createMenuItem(data);
  }

  async getAllMenuItems() {
    return menuRepository.getAllMenuItems();
  }

  async getMenuItemById(id) {
    const menuItem = await menuRepository.getMenuItemById(id);

    if (!menuItem) {
      throw new AppError("Menu item not found.", 404);
    }

    return menuItem;
  }

  async updateMenuItem(id, data) {
    await this.getMenuItemById(id);

    if (data.categoryId) {
      await this.getCategoryById(data.categoryId);
    }

    return menuRepository.updateMenuItem(id, data);
  }

  async deleteMenuItem(id) {
    await this.getMenuItemById(id);

    return menuRepository.deleteMenuItem(id);
  }

  // =====================================
  // OPTION GROUPS
  // =====================================

  async createOptionGroup(data) {
    await this.getMenuItemById(data.menuItemId);

    return menuRepository.createOptionGroup(data);
  }

  async updateOptionGroup(id, data) {
    return menuRepository.updateOptionGroup(id, data);
  }

  async deleteOptionGroup(id) {
    return menuRepository.deleteOptionGroup(id);
  }

  // =========================
  // Options
  // =========================

  async createOption(data) {
    const optionGroup = await menuRepository.getOptionGroupById(
      data.optionGroupId,
    );

    if (!optionGroup) {
      throw new AppError("Option group not found.", 404);
    }

    return menuRepository.createOption(data);
  }

  async getOptions(optionGroupId) {
    return menuRepository.getOptions(optionGroupId);
  }

  async getOptionById(id) {
    const option = await menuRepository.getOptionById(id);

    if (!option) {
      throw new AppError("Option not found.", 404);
    }

    return option;
  }

  async updateOption(id, data) {
    await this.getOptionById(id);

    return menuRepository.updateOption(id, data);
  }

  async deleteOption(id) {
    await this.getOptionById(id);

    return menuRepository.deleteOption(id);
  }

  // =========================
  // Option Groups
  // =========================

  async getOptionGroups(menuItemId) {
    return menuRepository.getOptionGroups(menuItemId);
  }

  async getOptionGroupById(id) {
    const optionGroup = await menuRepository.getOptionGroupById(id);

    if (!optionGroup) {
      throw new AppError("Option group not found.", 404);
    }

    return optionGroup;
  }
}

export default new MenuService();

export const getMenuTree = () => {
  return menuRepository.getMenuTree();
};
