import { Router } from "express";

import validate from "../../middleware/validate.js";

import {
  createCategory,
  getAllCategories,
  getCategoryById,
  updateCategory,
  deleteCategory,
  createMenuItem,
  getAllMenuItems,
  getMenuItemById,
  updateMenuItem,
  deleteMenuItem,
  createOptionGroup,
  getOptionGroups,
  getOptionGroupById,
  updateOptionGroup,
  deleteOptionGroup,
  createOption,
  getOptions,
  getOptionById,
  updateOption,
  deleteOption,
} from "./menu.controller.js";

import {
  createCategorySchema,
  updateCategorySchema,
  createMenuItemSchema,
  updateMenuItemSchema,
  createOptionGroupSchema,
  updateOptionGroupSchema,
  createOptionSchema,
  updateOptionSchema,
  idSchema,
  menuItemIdSchema,
  optionGroupIdSchema,
} from "./menu.validation.js";

const router = Router();

/* ============================
   Category Routes
============================ */

router.post("/categories", validate(createCategorySchema), createCategory);

router.get("/categories", getAllCategories);

router.get("/categories/:id", validate(idSchema), getCategoryById);

router.put(
  "/categories/:id",
  validate(idSchema),
  validate(updateCategorySchema),
  updateCategory,
);

router.delete("/categories/:id", validate(idSchema), deleteCategory);

/* ============================
   Menu Item Routes
============================ */

router.post("/items", validate(createMenuItemSchema), createMenuItem);

router.get("/items", getAllMenuItems);

router.get("/items/:id", validate(idSchema), getMenuItemById);

router.put(
  "/items/:id",
  validate(idSchema),
  validate(updateMenuItemSchema),
  updateMenuItem,
);

router.delete("/items/:id", validate(idSchema), deleteMenuItem);

// =========================
// Option Groups
// =========================

router.post(
  "/option-groups",
  validate(createOptionGroupSchema),
  createOptionGroup,
);

router.get(
  "/items/:menuItemId/option-groups",
  validate(menuItemIdSchema),
  getOptionGroups,
);

router.get(
  "/option-groups/:optionGroupId/options",
  validate(optionGroupIdSchema),
  getOptions,
);

router.put(
  "/option-groups/:id",
  validate(idSchema),
  validate(updateOptionGroupSchema),
  updateOptionGroup,
);

router.delete("/option-groups/:id", validate(idSchema), deleteOptionGroup);

// =========================
// Options
// =========================

router.post("/options", validate(createOptionSchema), createOption);

router.get("/option-groups/:optionGroupId/options", getOptions);

router.get("/options/:id", validate(idSchema), getOptionById);

router.put(
  "/options/:id",
  validate(idSchema),
  validate(updateOptionSchema),
  updateOption,
);

router.delete("/options/:id", validate(idSchema), deleteOption);

export default router;
