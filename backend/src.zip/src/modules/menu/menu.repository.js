import prisma from "../../database/prisma.js";

class menuRepository {
  // ==========================
  // Categories
  // ==========================

  async createCategory(data) {
    return prisma.category.create({
      data,
    });
  }

  async getAllCategories() {
    return prisma.category.findMany({
      where: {
        isActive: true,
      },
      orderBy: {
        sortOrder: "asc",
      },
      include: {
        _count: {
          select: {
            menuItems: true,
          },
        },
      },
    });
  }

  async getCategoryById(id) {
    return prisma.category.findUnique({
      where: { id },
      include: {
        menuItems: true,
      },
    });
  }

  async updateCategory(id, data) {
    return prisma.category.update({
      where: { id },
      data,
    });
  }

  async deleteCategory(id) {
    return prisma.category.delete({
      where: { id },
    });
  }

  async findCategoryByName(name) {
    return prisma.category.findFirst({
      where: {
        name: {
          equals: name,
          mode: "insensitive",
        },
      },
    });
  }

  // ==========================
  // Menu Items
  // ==========================

  async createMenuItem(data) {
    return prisma.menuItem.create({
      data,
    });
  }

  async getAllMenuItems() {
    return prisma.menuItem.findMany({
      where: {
        isAvailable: true,
      },
      include: {
        category: true,
        optionGroups: {
          include: {
            options: {
              where: {
                isAvailable: true,
              },
              orderBy: {
                sortOrder: "asc",
              },
            },
          },
          orderBy: {
            sortOrder: "asc",
          },
        },
      },
      orderBy: {
        createdAt: "desc",
      },
    });
  }

  async getMenuItemById(id) {
    return prisma.menuItem.findUnique({
      where: { id },
      include: {
        category: true,
        optionGroups: {
          include: {
            options: true,
          },
        },
      },
    });
  }

  async findMenuItemByName(name) {
    return prisma.menuItem.findFirst({
      where: {
        name: {
          equals: name,
          mode: "insensitive",
        },
      },
    });
  }

  async updateMenuItem(id, data) {
    return prisma.menuItem.update({
      where: { id },
      data,
    });
  }

  async deleteMenuItem(id) {
    return prisma.menuItem.delete({
      where: { id },
    });
  }

  // ==========================
  // Option Groups
  // ==========================

  async createOptionGroup(data) {
    return prisma.optionGroup.create({
      data,
    });
  }

  async updateOptionGroup(id, data) {
    return prisma.optionGroup.update({
      where: { id },
      data,
    });
  }

  async deleteOptionGroup(id) {
    return prisma.optionGroup.delete({
      where: { id },
    });
  }

  // =========================
  // Options
  // =========================

  async createOption(data) {
    return prisma.option.create({
      data,
    });
  }

  async getOptions(optionGroupId) {
    return prisma.option.findMany({
      where: { optionGroupId },
      orderBy: {
        sortOrder: "asc",
      },
    });
  }

  async getOptionById(id) {
    return prisma.option.findUnique({
      where: { id },
    });
  }

  async updateOption(id, data) {
    return prisma.option.update({
      where: { id },
      data,
    });
  }

  async deleteOption(id) {
    return prisma.option.delete({
      where: { id },
    });
  }

  // =========================
  // Option Groups
  // =========================

  async getOptionGroups(menuItemId) {
    return prisma.optionGroup.findMany({
      where: { menuItemId },
      include: {
        options: true,
      },
      orderBy: {
        sortOrder: "asc",
      },
    });
  }

  async getOptionGroupById(id) {
    return prisma.optionGroup.findUnique({
      where: { id },
      include: {
        options: true,
      },
    });
  }

  async getMenuTree() {
    return prisma.category.findMany({
      where: {
        isActive: true,
      },
      orderBy: {
        sortOrder: "asc",
      },
      include: {
        menuItems: {
          where: {
            isAvailable: true,
          },
          orderBy: {
            createdAt: "asc", // or name: "asc"
          },
          include: {
            optionGroups: {
              orderBy: {
                sortOrder: "asc",
              },
              include: {
                options: {
                  where: {
                    isAvailable: true,
                  },
                  orderBy: {
                    sortOrder: "asc",
                  },
                },
              },
            },
          },
        },
      },
    });
  }
}

export default new menuRepository();
