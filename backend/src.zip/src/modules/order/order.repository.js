import prisma from "../../database/prisma.js";

export const createOrder = (data, db = prisma) => {
  return db.order.create({ data });
};

export const createOrderItem = (data, db = prisma) => {
  return db.orderItem.create({
    data,
  });
};

export const createOrderItemOption = (data) => {
  return prisma.orderItemOption.create({
    data,
  });
};

export const getOrderById = (id) => {
  return prisma.order.findUnique({
    where: { id },
    include: {
      customer: true,
      items: {
        include: {
          menuItem: true,
          options: true,
        },
      },
    },
  });
};

export const getOrderByNumber = (orderNumber) => {
  return prisma.order.findUnique({
    where: { orderNumber },
    include: {
      customer: true,
      items: {
        include: {
          menuItem: true,
          options: true,
        },
      },
    },
  });
};

export const getCustomerOrders = (customerId) => {
  return prisma.order.findMany({
    where: { customerId },
    include: {
      items: {
        include: {
          menuItem: true,
          options: true,
        },
      },
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};

export const updateStatus = (id, status) => {
  return prisma.order.update({
    where: { id },
    data: { status },
  });
};
