import prisma from "../../database/prisma.js";

import * as orderRepository from "./order.repository.js";
import * as cartRepository from "../cart/cart.repository.js";

import AppError from "../../utils/AppError.js";

const generateOrderNumber = () => {
  return `ORD-${Date.now()}`;
};

export const checkout = async (customerId) => {
  const cart = await cartRepository.getCart(customerId);

  if (!cart || cart.items.length === 0) {
    throw new AppError("Cart is empty.", 400);
  }

  return prisma.$transaction(async (tx) => {
    let subtotal = 0;

    for (const item of cart.items) {
      subtotal += Number(item.totalPrice);
    }

    const tax = 0;
    const deliveryFee = 0;
    const total = subtotal + tax + deliveryFee;

    const order = await tx.order.create({
      data: {
        orderNumber: generateOrderNumber(),
        customerId,
        subtotal,
        tax,
        deliveryFee,
        total,
        status: "PENDING",
      },
    });

    for (const cartItem of cart.items) {
      const orderItem = await tx.orderItem.create({
        data: {
          orderId: order.id,
          menuItemId: cartItem.menuItemId,
          quantity: cartItem.quantity,
          basePrice: cartItem.basePrice,
          totalPrice: cartItem.totalPrice,
        },
      });

      for (const option of cartItem.options) {
        await tx.orderItemOption.create({
          data: {
            orderItemId: orderItem.id,
            optionId: option.optionId,
            name: option.name,
            extraPrice: option.extraPrice,
          },
        });
      }
    }

    await tx.cartItemOption.deleteMany({
      where: {
        cartItem: {
          cartId: cart.id,
        },
      },
    });

    await tx.cartItem.deleteMany({
      where: {
        cartId: cart.id,
      },
    });

    return order;
  });
};

export const getOrder = async (id) => {
  const order = await orderRepository.getOrderById(id);

  if (!order) {
    throw new AppError("Order not found.", 404);
  }

  return order;
};

export const getCustomerOrders = async (customerId) => {
  return orderRepository.getCustomerOrders(customerId);
};

export const updateStatus = async (id, status) => {
  return orderRepository.updateStatus(id, status);
};
