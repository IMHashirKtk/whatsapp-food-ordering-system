import { Router } from "express";

import controller from "./order.controller.js";

import validate from "../../middleware/validate.js";

import {
  checkoutSchema,
  orderIdSchema,
  customerOrdersSchema,
  updateStatusSchema,
} from "./order.validation.js";

const router = Router();

router.post("/checkout", validate(checkoutSchema), controller.checkout);

router.get("/:id", validate(orderIdSchema), controller.getOrder);

router.get(
  "/customer/:customerId",
  validate(customerOrdersSchema),
  controller.getCustomerOrders,
);

router.patch(
  "/:id/status",
  validate(updateStatusSchema),
  controller.updateStatus,
);

export default router;
