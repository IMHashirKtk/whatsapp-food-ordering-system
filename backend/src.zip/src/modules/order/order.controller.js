import asyncHandler from "../../utils/asyncHandler.js";
import * as orderService from "./order.service.js";

class OrderController {
  checkout = asyncHandler(async (req, res) => {
    const order = await orderService.checkout(req.body.customerId);

    res.status(201).json({
      success: true,
      message: "Order placed successfully.",
      data: order,
    });
  });

  getOrder = asyncHandler(async (req, res) => {
    const order = await orderService.getOrder(req.params.id);

    res.json({
      success: true,
      data: order,
    });
  });

  getCustomerOrders = asyncHandler(async (req, res) => {
    const orders = await orderService.getCustomerOrders(req.params.customerId);

    res.json({
      success: true,
      data: orders,
    });
  });

  updateStatus = asyncHandler(async (req, res) => {
    const order = await orderService.updateStatus(
      req.params.id,
      req.body.status,
    );

    res.json({
      success: true,
      message: "Order updated.",
      data: order,
    });
  });
}

export default new OrderController();
