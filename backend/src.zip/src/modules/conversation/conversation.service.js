import * as repository from "./conversation.repository.js";

export const getConversation = (customerId) => {
  return repository.getByCustomerId(customerId);
};

export const setState = async (customerId, state) => {
  return repository.upsert(customerId, state, {});
};

export const updateContext = async (customerId, context) => {
  const conversation = await repository.getByCustomerId(customerId);

  if (!conversation) {
    return repository.create({
      customerId,
      state: "MAIN_MENU",
      context,
    });
  }

  return repository.update(customerId, {
    context: {
      ...(conversation.context || {}),
      ...context,
    },
  });
};

export const reset = (customerId) => {
  return repository.upsert(customerId, "MAIN_MENU", {});
};
