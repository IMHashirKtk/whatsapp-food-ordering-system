import prisma from "../../database/prisma.js";

export const getByCustomerId = (customerId) => {
  return prisma.conversation.findUnique({
    where: { customerId },
  });
};

export const create = (data) => {
  return prisma.conversation.create({
    data,
  });
};

export const update = (customerId, data) => {
  return prisma.conversation.update({
    where: {
      customerId,
    },
    data,
  });
};

export const upsert = (customerId, state, context = {}) => {
  return prisma.conversation.upsert({
    where: {
      customerId,
    },
    update: {
      state,
      context,
    },
    create: {
      customerId,
      state,
      context,
    },
  });
};
